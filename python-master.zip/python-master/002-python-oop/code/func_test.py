num1 = None
num2 = None
        
def add1(self, num1, num2):
    return num1 + num2

def mul1(self, num1, num2):
    return num1 * num2
