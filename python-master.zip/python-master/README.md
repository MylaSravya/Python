# python
> (c) Venkata Bhattaram

![tinitiate](python-ms-logo.png "tinitiate python")
---
* Core Python Language
* Python Object Oriented Programming
* Python Modules
---

For Training and Project Support contact **syntaxboard@gmail.com**  | 
------------------------------------------------------------------- | 
